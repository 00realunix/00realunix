<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.ico" />
    <title>Document</title>
</head>
<body>
    <div id="app"><captcha v-if="active" link="./"></captcha></div>
    <script src="./assets/js/captcha.js"></script>
</body>
</html>